eXist XQuery Features Demo
=========

"Seeing is believing." 

This application contains various small demos for particular eXist features:

- Basic XQuery Examples
- XQuery 3.0 Examples
- Web Examples
- URL Rewriting
- Special Features
- Templating
- Content Extraction
- Unit Testing
- XForms and RestXQ
- RestXQ and AngularJS

Live demo on http://demo.exist-db.org/exist/apps/demo/ 
